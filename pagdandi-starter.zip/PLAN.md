# PLAN.md — Pagdandi (v2)

Eight working days, Wed 21 – Wed 28 October 2026. Submit Thursday 29 October.
One phase per Claude Code session. Each phase: Plan Mode → approve → implement →
verify → teach-back (Prompt 5) → commit (Prompt 3).

Legend: **[T1]** must · **[E]** engine/evaluation must · **[T2]** only if time.

**Honest load warning.** v2 is about 40 % bigger than v1 in the same 8 days. It
fits only if each day stays on its phase, and you'll need ~8–9 focused hours a
day. If a day slips by more than half, run Prompt 10 with the SPEC §4 cut order
that evening; don't carry debt into the next day.

## Calendar

| Day | Date | Phases | End-of-day check |
|---|---|---|---|
| 0 | Tue 20 Oct (tonight) | Prompt 1 + Prompt 2; answer Q1–Q6 | SPEC updated with your answers |
| 1 | Wed 21 | P0 Setup (incl. fonts, i18n) · P1 Data: OSM city + Wikidata India + Commons | Places with names in many scripts at `/api/cities/<slug>/places` |
| 2 | Thu 22 | P2 Design system, Explore list, Place page, ranking, names | Explore + Place match the reference |
| 3 | Fri 23 | P3 Accounts, likes, follows, kadam · P4 Nearby deck | Deck swipes on your phone |
| 4 | Sat 24 | P5 Media pipeline, Add (3 flows), Watch feed | Post a video; it plays in Watch |
| 5 | Sun 25 | P6 Check-in, Pulse, Explore map + fog, You/Passport, profiles · **Tier 1 gate** · go out: add 2 places + 2 videos on site | Prompt 6 passes |
| 6 | Mon 26 | P7 Partner engine + Studio · P8 Simulations + demo data | Studio shows simulated earnings; results/ filled |
| 7 | Tue 27 | P9 Polish, reviews, Tier 2 picks | Prompts 7 + 8 issues fixed |
| 8 | Wed 28 | P10 Report, viva, rehearsal · **code freeze 12:00** | You can demo and explain everything |
| — | Thu 29 | Submit | |

Team split (if not solo): backend person P1, P3, P5-backend, P7, P8; frontend person
P2, P4-UI, P5-UI (Add, Watch), P6-UI, Studio UI.

---

## Phase 0 — Setup [T1] (Day 1 morning, ~2 h)
- [ ] Repo per CLAUDE.md; `.gitignore` (media, db, data/, env, venv, node_modules).
- [ ] Backend: FastAPI `/api/health`, config loader, SQLite engine, pytest.
- [ ] Frontend: Vite React TS, Router with Nearby, Watch, Explore, Place, Add, You,
      Settings; proxy `/api` `/media`; basic-ssl behind `--host`.
- [ ] `tokens.css` (SPEC §12.2, both themes), `base.css`, `fonts.css` with all
      @fontsource families from CLAUDE.md and one font stack (SPEC §12.3).
- [ ] i18next with `en.json`; `format.ts` (en-IN numbers), `<Money>` with Simulated tag.
- [ ] Bottom nav: Nearby · Watch · (+) · Explore · You.
- [ ] Commit skill (Prompt 3) and first commit.
- **Done when**: screens and nav render in light and dark on laptop and phone; a
  test page shows one word in each of the 23 languages with correct glyphs.

## Phase 1 — Data [T1] (Day 1, ~6 h)
- [ ] `models.py`: all SPEC §5 tables; FTS5 over PlaceName.
- [ ] `geo.py` haversine + bbox (tests with known distances).
- [ ] `seed_osm.py` (SPEC §6.1): Overpass per category, cache, centroids, `name:*`
      → PlaceName, neighbourhoods, idempotent.
- [ ] `seed_wikidata.py` (SPEC §6.2): verify class QIDs and the state/UT QIDs in the
      query service first; one query per class; labels in 23 languages; image,
      sitelinks, heritage, state via `P131*`; merge with OSM; idempotent.
- [ ] `commons.py` (SPEC §6.3): lazy fetch, licence allowlist, attribution fields,
      local cache, `/api/media/commons/{id}`.
- [ ] Fame (SPEC §6.7). Endpoints: `/cities`, `/cities/{slug}/places?sort=near`,
      `/places/{id}`.
- [ ] Tests: AC-1, AC-2, AC-3 on saved fixture JSON (never live APIs in tests).
- [ ] Fill Measured values: places per state/category, % with photo, % with each
      language's name.
- **Watch**: Wikidata 60 s timeouts → smaller class batches; Commons 429 → back off.

## Phase 2 — Design system, Explore list, Place page, ranking, names [T1] (Day 2)
- [ ] `ranking/` Wilson, gems, trending with SPEC §9.1–9.3 tests.
- [ ] `names.py` + `lib/names.ts` (SPEC §7.2) + `NameBlock`; tests for 3 modes,
      `lang` attrs, `<bdi>` for RTL.
- [ ] Sort endpoint (5 sorts), category filter, verified toggle, search (FTS5, any script).
- [ ] Components: PlaceRow, SortTabs, CategoryChip, Stat, SafetyCard, StepList,
      TipNote, LivePill, PulseStrip (static), EmptyState, illustrations.
- [ ] Explore List screen; Place page with all SPEC §8.5 sections (actions disabled
      until sign-in); Open in Maps; attribution for OSM/Wikidata/Commons.
- [ ] Fragile server rule (AC-15 part) now.
- **Done when**: AC-4 (except Languages screen), AC-5 (list part), AC-6 pass; screenshots
  match the reference (Prompt 7 quick check).

## Phase 3 — Accounts, likes, follows, kadam [T1] (Day 3 morning)
- [ ] Auth (argon2id, hashed sessions, cookie flags, `X-Requested-With`).
- [ ] Like/save/view; MediaLike; Follow; profiles `/users/{handle}`.
- [ ] `kadam.py` (all SPEC §10.1 rules and caps), reports API.
- [ ] Settings screen: names mode + language, UI language (English only enabled),
      theme; Languages & cities screen as in the reference.
- [ ] Tests: AC-9, AC-14 (rules available so far), AC-4 Languages screen glyph check.

## Phase 4 — Nearby deck [T1] (Day 3 afternoon)
- [ ] `deck/thompson.py`, `deck/rank.py` (SPEC §9.4); `/deck`, `/deck/swipe`.
- [ ] DeckCard + DeckActions (gestures, buttons, reduced motion, preload, end card,
      radius chips, location fallback, Live pill).
- [ ] Tests: AC-10.
- **Done when**: saving waterfalls brings more waterfalls within ~10 swipes on your phone.

## Phase 5 — Media, Add, Watch [T1] (Day 4)
- [ ] `media_store.py`: magic-byte checks, Pillow re-encode without EXIF, video
      limits (60 s / 60 MB), posters, Range serving.
- [ ] `integrity/phash.py`, `exif.py`, `dedupe.py` (all names, all languages).
- [ ] Client EXIF read, resize, video duration + poster.
- [ ] (+) sheet; Add a new place (3 steps, duplicate prompt); Add photos/video to a
      place; content rules sheet.
- [ ] `watch/rank.py` (SPEC §9.5), `watch/views.py` (engaged/completed from heartbeat,
      §9.10 view rules); `/watch`, `/watch/{id}/view`; Touch recording.
- [ ] WatchPlayer + WatchRail + tabs; Go here; saveData path; 20-min nudge.
- [ ] Tests: AC-7, AC-11.
- **Done when**: you post a 20 s video from your phone and it appears in Watch.

## Phase 6 — Check-in, Pulse, Map + fog, You [T1] (Day 5)
- [ ] `/checkin` (SPEC §8.7), fraud flags, place verification, kadam; dev simulator.
- [ ] Pulse endpoint + form + summaries (SPEC §8.8); Live pill everywhere.
- [ ] Last-mile: write versions, vote, best by Wilson.
- [ ] Explore Map: OpenFreeMap restyle (6 paint overrides), boundary layers hidden,
      pins, clusters, fog (turf), neighbourhood count, bottom sheet.
- [ ] You: Passport (stamps, streak, kadam, found, want to go) + public profile.
- [ ] Fragile pledge UI.
- [ ] Tests: AC-8, AC-12, AC-13, AC-14 (all), AC-15, AC-25.
- **Tier 1 gate (Prompt 6)**: AC-1 to AC-15 and AC-25 pass; journey on the phone:
  deck → save → place → check in (simulator) → Pulse → fog clears → stamp → Watch →
  Go here.
- **Then go outside** (Sat/Sun): add 2 real places and 2 real videos on site; check in
  to 2 seeded places; post 1 Pulse.

## Phase 7 — Partner engine + Studio [E] (Day 6 morning)
- [ ] `partner/attribution.py` (SPEC §9.9), `invalid.py` (§9.10 rules + velocity hold),
      `eligibility.py` (§10.4), `split.py` (§10.3, paise, rounding down).
- [ ] `/admin/partner/run?month=`; `/studio`.
- [ ] Studio screen: banner, metric cards + sparklines (text values too), checklist,
      top content, audience, "How earnings are split" sheet.
- [ ] Tests: AC-16, AC-17, AC-18, AC-19, AC-23.

## Phase 8 — Simulations + demo data [E] (Day 6 afternoon)
- [ ] `sim/ranking_sim.py` (SPEC §17 item 1), `bandit_sim.py` (item 2),
      `attribution_sim.py` (item 3), `fraud_sim.py` (item 4). Sims import the real
      functions, never copies.
- [ ] pHash robustness (item 5) on your own photos (not committed).
- [ ] Coverage table (item 7) from the DB.
- [ ] `scripts/demo_data.py` (item 9) then run the Partner month on demo data.
- [ ] README results quoting `metrics.json`; Prompt 9 audit.
- [ ] Tests: AC-24.

## Phase 9 — Polish, reviews, Tier 2 [T2 + fixes] (Day 7)
- [ ] Prompt 7 design critique on all 9 screens, both themes; fix the top 10.
- [ ] Prompt 8 independent security/privacy/fraud review; fix high + medium.
- [ ] AC-20, AC-21, AC-22 in Playwright.
- [ ] Lighthouse mobile on Nearby and Watch; fix the top 2 issues each.
- [ ] Tier 2, in order, stop at 18:00: Hindi + regional UI (Prompt 14, native-reviewed) → comments
      → golden hour → Weekly Trail → Trails → clans → admin UI → offline → Isolation
      Forest → CLIP → IndicXlit batch (Prompt 13) → Wikivoyage.

## Phase 10 — Report, viva, rehearsal (Day 8) — code freeze 12:00
- [ ] `docs/REPORT.md` (Prompt 11).
- [ ] 3-minute screen recording of the journey (backup for the live demo).
- [ ] Demo rehearsal (Prompt 12).
- [ ] Viva drill with `docs/VIVA.md` (Prompt 5 quiz mode).
- [ ] Final commit, tag `v1.0-submission`.

---

## Risks

| # | Risk | Likelihood | Mitigation |
|---|---|---|---|
| R1 | Overpass / Wikidata timeouts | Medium | Per-class queries, caching, fixtures for tests |
| R2 | Commons rate limits / odd licences | Medium | ≤ 2 req/s, allowlist, illustration fallback |
| R3 | Geolocation blocked on phone (no HTTPS) | High | basic-ssl; simulator for the viva |
| R4 | Too much scope for 8 days | **High** | Strict daily phases; Prompt 10 cut order the same evening |
| R5 | Video playback/size issues | Medium | Limits, poster first, Range test, MP4 H.264 advice |
| R6 | Indic text renders wrong (missing glyphs, wrong font) | Medium | Phase 0 glyph test page for all 23 languages; `lang` attrs |
| R7 | Wrong place names in some languages (data errors) | Medium | Show source; users add/vote names; report "wrong name" |
| R8 | Map restyle eats time | Medium | 6 paint overrides only; hide boundary layers by id |
| R9 | Attribution bugs credit the wrong creator | Medium | Fixture tests to 1e-9 (AC-16) + simulation |
| R10 | Examiner: "is this AI?" | High | VIVA.md section C: ranking under uncertainty, bandits, attribution, fraud detection, hashing, (CLIP, IndicXlit) |
| R11 | Live demo fails (Wi-Fi) | Medium | Localhost; browse map once to cache tiles; recording backup |
| R12 | Machine-translated UI shipped by mistake | Low | Invariant 11; only `en` enabled in Tier 1 |

## Measured values

| What | Value | Phase |
|---|---|---|
| OSM places / neighbourhoods (deep city) | | P1 |
| Wikidata places in India (total, per class) | | P1 |
| Share with a Commons photo (allowlisted) | | P1 |
| Share with a name in each language (23 numbers) | | P1 |
| Deck endpoint p95 (ms) | | P4 |
| Watch first-frame time on phone (s) | | P5 |
| Median upload size after resize (KB) | | P5 |
| Outdoor check-in accuracy (m) | | P6 |
| Ranking sim precision@10: raw / ratio / Wilson | | P8 |
| Bandit sim save rate @30: random / popular / fixed / Thompson | | P8 |
| Attribution sim Spearman ρ: last-touch / linear / time-decay | | P8 |
| Fraud sim precision / recall of rules | | P8 |
| pHash detection / false-match rate | | P8 |
| Lighthouse mobile (Nearby / Watch) | | P9 |
| axe serious/critical issues | | P9 |

## Ideas parked
- (Add here instead of building.)

## Progress log
- 2026-10-20 — v1 spec, plan, design reference.
- 2026-10-20 — v2: languages, all-India open data, Watch, Pulse, Partner Program, Studio.
